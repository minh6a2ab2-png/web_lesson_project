# Changelog

## 2026-11-17 — MT2-FROZEN (definition only)
- Chuẩn hóa 13/13 SKILL.md từ nguồn MT1 được kiểm chứng, giữ baseline và nguồn băm; phân định vai trò/đầu ra của từng bước.
- Khóa các lỗi tái diễn từ Cookies Skill13: mục lục/nhảy bước, tracking coverage, modal focus, cleanup local progress, VI/EN giả, lộ answer key, tự động MASTERED.
- Skill04 có rubric lựa chọn có trọng số minh bạch, Skill07 bắt buộc sản xuất file thực khi khả thi, Skill08 theo 4 bước 5512, Skill13 phân biệt gate.
- Tách rõ fixture (test) khỏi demo thật; không tạo website demo trong giai đoạn này.
- Bổ sung suite integrity tests + SHA256 + runbook backup.
- `main` và các bản sao MT1 không bị ghi đè.

## 2026-11-17 — MT1 (nguồn)
- Khởi tạo chuẩn đa topic, 25 negative regression tests, sample fixture chỉ để validation.
