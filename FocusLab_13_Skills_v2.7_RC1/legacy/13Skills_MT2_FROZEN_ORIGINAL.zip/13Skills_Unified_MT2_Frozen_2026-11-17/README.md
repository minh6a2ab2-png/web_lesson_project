# 13 Skills — MT2 phiên bản thống nhất và cố định (17/11/2026)

Mục đích: xây dựng một **bộ 13 Skills hoàn chỉnh nhất hiện có**, kế thừa đầy đủ gói MT1 cùng bản sửa lỗi/QA của Cookies được liệt kê trong `SOURCE_LEDGER.md`, sẵn sàng sử dụng **sau này** cho bài demo một buổi có một hoặc nhiều chủ đề. Bản này **chỉ đóng gói phương pháp, chưa dựng demo**.

## Sử dụng
Đọc `START_HERE.md` trước, sau đó `THONG_NHAT_13_SKILLS.md`, `policy/UNIFIED_RULES_MT2.md`, rồi `skills/skill01` … `skill13`. Giữ số thứ tự Cookies/MT1: 09 architect, 10 visual, 11 HTML, 12 learner audit, 13 final QA.

## Đầu ra và bằng chứng
- **13/13** SKILL.md chuẩn MT2, kèm baseline từ MT1 và các quy chuẩn chính.
- `SKILL_HANDOFF_MATRIX.csv` xác định ranh giới mỗi bước, `policy/UNIFIED_RULES_MT2.md` khóa các lỗi tái diễn.
- `fixtures/multi_topic_120min/` là dữ liệu **giả lập chỉ dùng cho tests**, không phải giáo án thật hay demo đã tạo.
- `tests/validate_multitopic.py`, `tests/test_regression.py` và `tests/check_suite_mt2.py` kiểm tra cấu trúc & đồng bộ. Không thay thế thử nghiệm website trên browser hoặc học sinh thật.

## Chưa thực hiện
- Chưa triển khai Skills 01→13 lên một buổi học mới.
- Chưa lập trình hoặc phát hành website demo.
- Chưa kiểm nghiệm trên học sinh thật, không tuyên bố `FIELD_VALIDATED`/`RELEASE_PASS`.
- **Không tự động nhập vào main GitHub** hay xóa các nhánh/ZIP cũ.

## Phát hành
Gói này là **definition release**, chỉ thông báo `DEFINITION_QA_PASS` khi test đạt. Bộ file `teacher_key` trong fixture chỉ là dữ liệu thử được cô lập, không phải web bundle.
