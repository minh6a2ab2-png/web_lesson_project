# Sử dụng MT2 thay MT1 trong lần demo kế tiếp

- Dùng MT2-FROZEN làm nguồn định nghĩa của **13 Skills**; không trộn số Skill09–13 với `13-skill-workflow-v4.md`.
- Không tự cập nhật `main` hoặc file MT1; chọn nhánh/copy MT2 khi bắt đầu bài thật.
- Dữ liệu ban đầu phải có `lesson_id`, learner profile, thời lượng `PROPOSED/USER_APPROVED`, tài liệu tối thiểu và chủ đề cần dạy. **Nếu chưa có, Skill01 chỉ liệt kê GAP và tiến hành nghiên cứu có kiểm chứng.**
- Thực hiện Skill01 → 13 có checkpoint và nguồn thực; mỗi bước chỉ chạy khi người dùng yêu cầu. Trong một chủ đề vẫn dùng cùng quy tắc section.
- `fixtures/` kiểm tra validator, KHÔNG phải buổi demo đã làm.
- Khi nghiệm thu bài demo tương lai, chạy lại kiểm tra browser và field; outcome QA của MT2 chỉ áp dụng định nghĩa kỹ thuật.
