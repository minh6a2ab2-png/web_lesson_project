# Scope, điều đã sửa và còn mở

## Đã sửa ở bộ SKILLS
- Ranh giới 01/02/03/04 (nội dung trước phương pháp), 05/07 (curation vs production), 09/10/11 (architecture/design/runtime), 12/13 (simulated vs independent QA).
- Định nghĩa rõ Recall→Quiz theo CORE SECTION thay vì từng KU, trình bày HS, ID, time budgets, cross-topic bridges, answer-key isolation, điều hướng có guard, VI/EN đủ mới bật, cleanup localStorage trên máy chung, browser QA.
- Skill04 có rubric 5 tiêu chí với trọng số mặc định 100%.

## Chưa sửa (không thuộc lần này)
- Bảy issue của **website Cookies Skill11 v1.2** vẫn tồn đọng; đây là sửa quy tắc để tránh lỗi trong bài tiếp, **không phải patch website cũ**.
- Chưa chạy bất kỳ bài demo thật nào với MT2; runtime/browser, kiểm nghiệm người học, phát hành sản phẩm đều NOT_RUN.
- Phiên bản này không nhập GitHub main.
