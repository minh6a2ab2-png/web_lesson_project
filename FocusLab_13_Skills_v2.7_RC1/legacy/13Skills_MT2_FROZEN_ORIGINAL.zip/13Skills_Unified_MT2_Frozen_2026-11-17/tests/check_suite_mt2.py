#!/usr/bin/env python3
import pathlib,re,hashlib,json,csv,sys
root=pathlib.Path(__file__).resolve().parents[1]
errors=[]; findings=[]
for i in range(1,14):
 p=root/f'skills/skill{i:02d}/SKILL.md'
 if not p.is_file():errors.append(f'MISSING:{p}');continue
 t=p.read_text('utf-8')
 for s in ('version: 2026.11-MT2-FROZEN','## Nhiệm vụ và ranh giới','## Đầu ra, giữ nguyên tên và ID','## Chuẩn hóa chất lượng MT2','### Cách đóng cổng và bàn giao sang bước tiếp'):
  if s not in t:errors.append(f'SKILL{i:02d} missing {s}')
 for s in ('Recall', 'Quiz','section_id','NOT_RUN'):
  if s not in t:errors.append(f'SKILL{i:02d} missing {s}')
 findings.append({'skill':i,'bytes':len(t.encode())})
for f in ['START_HERE.md','README.md','policy/UNIFIED_RULES_MT2.md','policy/MT_CONTRACT.md','policy/GATES_AND_ROUTES.md','SKILL_HANDOFF_MATRIX.csv','SOURCE_LEDGER.md','THONG_NHAT_13_SKILLS.md','MIGRATION_GUIDE.md','reports/MT2_SCOPE_AND_KNOWN_ISSUES.md']:
 if not (root/f).is_file():errors.append('MISSING:'+f)
rules=(root/'policy/UNIFIED_RULES_MT2.md').read_text('utf-8')
for term in ['25/25/20/15/15','SKIPPED','MASTERED','EXIT','CV5512','FIELD_VALIDATED','READY_ASSET','inquiry','teacher']:
 if term not in rules:errors.append('RULES MISSING:'+term)
m=(root/'VERSION_MATRIX.csv').read_text('utf-8-sig').splitlines()
if len(m)!=14:errors.append(f'VERSION_MATRIX expected 13 rows, got {len(m)-1}')
result={'suite':'MT2-FROZEN','skills_found':len(findings),'checks':'PASS' if not errors else 'FAIL','errors':errors,'definition_release_only':True,'demo_created':False}
print(json.dumps(result,ensure_ascii=False,indent=2));sys.exit(0 if not errors else 1)
