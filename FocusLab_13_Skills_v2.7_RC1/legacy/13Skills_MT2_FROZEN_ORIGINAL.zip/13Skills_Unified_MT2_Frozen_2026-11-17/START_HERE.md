# BẮT ĐẦU TẠI ĐÂY — BỘ 13 SKILLS CHUẨN THỐNG NHẤT MT2

**Phiên bản chốt:** `2026.11-MT2-FROZEN` (17/11/2026). **Phạm vi:** định nghĩa quy trình thiết kế bài giảng một hoặc nhiều nội dung, CHƯA thực hiện demo.

1. Đọc `README.md`, `THONG_NHAT_13_SKILLS.md`, `policy/UNIFIED_RULES_MT2.md`, `policy/MT_CONTRACT.md` và `SKILL_HANDOFF_MATRIX.csv`.
2. Dùng theo thứ tự `skills/skill01/SKILL.md` đến `skills/skill13/SKILL.md`. Chỉ chạy những skills người dùng yêu cầu; không mặc định làm luôn website.
3. Dùng `fixtures/` để kiểm định **cấu trúc** chứ không phải giáo án thật được phê duyệt. Không lấy thời lượng 120 phút làm mặc định.
4. Khi dự án bài thật bắt đầu, thu thập nội dung/SGK/người học/giờ học, gắn mã ID, chạy lần lượt với cổng nghiệm thu mỗi bước; lưu evidence và QA tách riêng.
5. Bản Cookies Skill11 v1.2 cũ vẫn bị chặn phát hành; các cập nhật MT2 sửa *định nghĩa và quy tắc* để tránh tái diễn lỗi, không tự sửa source website Cookies.
6. Kiểm tra SHA tại `MANIFEST_SHA256.json`, các file trong package bằng `python tests/check_suite_mt2.py`. Gói ZIP có SHA riêng trong biên bản cùng tên `.sha256`.

**Trạng thái:** `DEFINITION_READY / STATIC_SUITE_TESTED / LESSON_DEMO_NOT_STARTED / RUNTIME_NOT_RUN / FIELD_NOT_VALIDATED`.
