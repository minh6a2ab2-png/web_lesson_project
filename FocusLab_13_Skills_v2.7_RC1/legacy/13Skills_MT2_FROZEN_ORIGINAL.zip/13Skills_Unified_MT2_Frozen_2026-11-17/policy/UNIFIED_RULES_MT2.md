# QUY ĐỊNH CHUNG — 13 Skills MT2-FROZEN

**Tài liệu có hiệu lực cao hơn `SKILL.md` khi cần kiểm tra liên bước.** `MT_CONTRACT.md` là đặc tả dữ liệu chi tiết; các `BASELINE_NOTES.md` giữ lịch sử gốc.

## 1. Input, ID, output và state
- `lesson_id → topic_id → section_id → ku_id` có quan hệ tổ tiên chính xác; `objective_id`, `scene_id`, `activity_id`, `asset_id`, `cue_id`, `question_id` duy nhất và không tái cấp cho đối tượng mới.
- Mỗi bước nộp `skill_id`, `version`, `input_refs`, `outputs`, `evidence`, `open_issues`, `gate_status`, `next_step`. Không có bằng chứng thì `NOT_RUN`/`UNVERIFIED` chứ không gán hoàn thành.
- `PROPOSED`, `USER_APPROVED`, `SIMULATED`, `VERIFIED`, `FIELD_NOT_VALIDATED` là trạng thái khác nhau; giờ minh họa không phải giờ được duyệt.

## 2. Trình tự chuẩn và ranh giới
- **01** kiểm nguồn; **02** phân bổ mục tiêu/thời lượng; **03** viết nội dung đầy đủ; **04** chọn phương pháp; **05** tìm tài nguyên; **06** kịch bản; **07** tạo/kiểm học liệu thật; **08** giáo án CV5512; **09** scene/điều hướng; **10** thiết kế hi-fi; **11** code; **12** mô phỏng học sinh; **13** QA độc lập.
- Bước 02/03 không chốt method; bước 05 không giả danh asset hoàn tất; bước 09 không dựng giao diện; bước 10 không nhận code; bước 12 không cấp kết quả field; bước 13 không công nhận tự chứng minh từ 11.

## 3. Phương pháp giáo dục
- Theo từng section, rà học sinh, độ nặng, trải nghiệm thật, thời gian và nguồn lực. Skill04 dùng rubric 25/25/20/15/15 mặc định, điểm 0–5, có ít nhất 2 phương án; nếu đổi trọng số phải giải thích.
- Khái niệm dễ: TEACH ngắn + HS trình bày lại; nội dung phức hợp/quan sát được: dự đoán, thao tác, nói kết quả, rút kết luận; không inquiry cho mọi khái niệm. Người học chủ động tối đa nhưng không quá tải.
- Cuối mỗi CORE `section`: Recall 2–4 cue hiện từng bước, HS **nói rồi ghi/vẽ** trước feedback, sau đó Quiz 2–4 câu đa dạng ít nhất 2 hình thức và có phản hồi khi sai; không tự tạo Recall cho mỗi KU.
- Một game ôn đầu hoặc cuối BUỔI. Sau giờ có mindmap vẽ lại, flashcard định nghĩa và teach-back có tiêu chí.
- Bài nhiều topic cần trục tình huống liên hệ, graph tiên quyết, cầu nối chủ đề, transfer và EXIT độc lập; không ghép nhiều website rời.

## 4. Học liệu, bản quyền, fallback
- Nguồn đáng tin và thực tế vượt mức SGK nếu cần, thông tin được kiểm chứng theo thời điểm; tài nguyên có tình trạng `READY_REFERENCE`, `READY_ASSET`, `PROTOTYPE`, `SPEC_ONLY`, `BLOCKED`.
- Skill07 tạo file thật khi khả thi, kèm mã/nguồn/license/alt/caption/transcript song ngữ nếu phù hợp/giải pháp offline/kiểm tra mở/hash.
- Trình duyệt thật khi nhiệm vụ yêu cầu quan sát hành vi thực; mô phỏng không được ngụy tạo thành dữ liệu quan sát.

## 5. CV5512 / Web
- Giáo án CV5512: bốn bước giao nhiệm vụ → HS làm → báo cáo/thảo luận → đánh giá/kết luận, có sản phẩm đo được và nội dung học chính xác.
- Web HTML thuần mặc định, UI slide lớn, không có header che, nút Home/Back/Next; bố cục theo loại nội dung, tối ưu mobile/zoom/keyboard.
- Next/TOC/keyboard/deep link/resume đều dùng chung guard, xin xác nhận và ghi SKIPPED khi bỏ qua; không gọi click là MASTERED. Recall không lộ mẫu trước tự thử; Quiz có phản hồi/thử lại.
- Toggle VI/EN chỉ bật khi dịch đủ nội dung và kiểm tra; EXIT key riêng teacher không nằm trong HTML phía học sinh; có cơ chế xóa tiến độ máy chung, không thu dữ liệu nhạy cảm không cần thiết.

## 6. Gate và phát hành
- `DEFINITION_QA_PASS` (bộ skill tĩnh) ≠ `STATIC_STRUCTURE_PASS` (fixture) ≠ `RUNTIME_BROWSER_PASS` (website) ≠ `FIELD_VALIDATED` (học sinh thật) ≠ `RELEASE_PASS` (được phép dùng rộng).
- Issue lỗi P1/rò đáp án/CORE thiếu/skip guard bypass -> `RELEASE_BLOCKED` đối với website. Khi chưa có browser thực tế thì ghi `NOT_RUN`.
- Thay mục tiêu, scene, ngân sách, hoạt động đã duyệt phải lập CR; chạy lại các test tác động và giữ phiên bản nguồn. Không tự ý cập nhật GitHub `main`.

## 7. Ràng buộc giai đoạn hiện tại
**Chỉ phát hành định nghĩa 13 Skills + bộ kiểm tra tĩnh + bản sao lưu. KHÔNG tạo demo, giáo án bài thật, website chạy thật, hoặc tuyên bố đã test học sinh.**
