# Change log MT2

**2026-11-17**: sao từ `MultiTopic_13Skills_MT1_2026-11-17.zip` (52 tệp), giữ đủ 13 SKILL + baseline/policy/fixture/tests. Chuẩn hóa role/status/version, thêm `UNIFIED_RULES_MT2.md` và phần bắt buộc riêng mỗi skill; không thay đổi 19 scene fixture gốc để chạy hồi quy. Bổ sung giáo án + website demo 120 phút, tài nguyên và QA.

**Không đưa vào:** thay thế gói Cookies Skill11 v1.2, sửa 7 issue của website Cookies cũ, merge tự động `main`, phê duyệt thời lượng dạy thật.
