# QUY TRÌNH 13 SKILLS DUY NHẤT — MT2 FROZEN

**Thứ tự cố định** (bài 1 chủ đề hoặc nhiều chủ đề đều dùng cùng pipeline):

| Bước | Skill | Trách nhiệm chính | Cổng bàn giao |
|---|---|---|---|
| 01 | Content Research & Analysis | Nghiên cứu nguồn, kiến thức thực tế, tiên quyết, độ tin cậy | Mọi CORE KU có nguồn/trạng thái minh bạch |
| 02 | Lesson Architecture & Assessment | Chốt mục tiêu, section và thời gian, ma trận đánh giá | Thời gian cân, học sinh cần làm gì rõ |
| 03 | Knowledge Content Author | Viết **đủ kiến thức phải dạy** trước phương pháp | Không thiếu định nghĩa / nhầm lẫn kỹ thuật |
| 04 | Learner Profile Fit & Activity Design | Chọn phương pháp bằng rubric + scaffold | Có căn cứ theo section, không inquiry tràn lan |
| 05 | Learning Resource Curator | Tìm/chọn học liệu và nguồn, kế hoạch fallback | Có nguồn/license, chưa nhận đã sản xuất |
| 06 | Teaching Scenario Writer | Kịch bản lời dẫn–HS thực hành–phản hồi–bridge | Lời GV ngắn, người học có đầu ra |
| 07 | Activity Resource Designer | **Tạo asset thật**, kiểm mở và trạng thái | READY có file, không có thì báo BLOCKED |
| 08 | CV5512 Lesson Plan Writer | Soạn giáo án một buổi theo 4 bước | Có sản phẩm, đánh giá, thời gian, phương án hỗ trợ |
| 09 | Interactive Website Architect | Scene/logic/điều hướng, recall/quiz/EXIT | Guard thống nhất, ID toàn cục |
| 10 | Learning Experience Visual Designer | Hi-fi slide/web theo từng scene | Responsive/a11y/VI-EN đã thiết kế đúng |
| 11 | HTML Lesson Developer | Code HTML thuần và kiểm tra trên browser | Không rò key, không tự gọi VISITED là MASTERED |
| 12 | Learner Perspective Simulation | Audit đường học/nhầm nền/bỏ qua/tạm dừng | Issue register và phân biệt mô phỏng–HS thật |
| 13 | Independent Final QA | Kiểm định độc lập, quyết định có phát hành | Phân biệt definition/static/runtime/field/release |

## Những điểm bất biến
- Một lesson session chứa 1+ topic, topic chứa section, section chứa knowledge unit; không nhất thiết một topic = một section.
- Chỉ section CORE cần một cặp Active Recall → Quiz (2–4 cue và 2–4 câu, ≥2 dạng) sau khi học, trước khi sang topic/section tiếp theo. Không lặp trên mỗi khái niệm nhỏ.
- HS tự nói rồi ghi/vẽ trước khi đối chiếu. Có game ôn một lần toàn buổi, mindmap/flashcard/teach-back hậu buổi.
- Skill03 chuẩn bị nội dung *trước* Skill04 quyết định hoạt động; Skill05 tìm nguồn *khác với* Skill07 trực tiếp làm học liệu.
- Lesson plan CV5512: Chuyển giao → Thực hiện → Báo cáo/Thảo luận → Đánh giá/Kết luận.
- Website dạng slide lớn, HTML thuần, điều hướng rõ, có Home; browser thật khi hữu ích, simulation gắn nhãn.
- Evidence statuses được tách; NEXT/TOC/shortcut/resume không âm thầm bypass Recall/Quiz; teacher EXIT key ở ngoài student web.
- Nội dung source/thiết kế/phê duyệt thay đổi => change request, QA hồi quy.

**Mọi đánh giá tích hợp sau đây thuộc giai đoạn triển khai demo sau này**, không phải bộ Skills vừa phát hành đã có website chạy.
